<template>
<div>
    Bet
</div>
</template>

<script>
export default {
  name: 'bet'
}
</script>
