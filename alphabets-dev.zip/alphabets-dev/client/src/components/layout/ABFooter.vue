<template>
<v-footer app>
<a href="http://alpha-bets.world" target="_blank" class="accent--text">AlphaBets</a>&nbsp;<span class="primary--text">- Innovative betting using the Blockchain</span>
</v-footer>
</template>

<script>
export default {
  name: 'ab-footer'
}
</script>
