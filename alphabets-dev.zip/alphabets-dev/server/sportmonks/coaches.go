package sportmonks

import (
	
)

type CoachesTeam struct{
	LocalTeamCoachId int `json:"localteam_coach_id"`
	VisitorTeamCoachId int `json:"visitorteam_coach_id"`
}