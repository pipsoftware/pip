package sportmonks

import (
	
)







type StatsTeam struct{}