package sportmonks

import (
)

type Ranking struct{
	LocalTeamPosition int `json:"localteam_position"`
	VisitorTeamPosition int `json:"visitorteam_position"`
}