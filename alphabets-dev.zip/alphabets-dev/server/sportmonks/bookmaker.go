package sportmonks

// type Bookmarker struct {
// 	ID   int    `json:"id"`
// 	Name string `json:"name"`
// 	ODDS Odds   `json:"odds"`
// }
