package sportmonks

import (
	
)

type TvStations struct{
	FixtureId int `json: "fixture_id"`
	TvStation string `json: "tvstation"`
}
