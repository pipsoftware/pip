package sportmonks

import (
	
)



type FormationTeam struct{
	LocalTeamFormation string `json:"localteam_formation"`
	VisitorTeamFormation string `json:"visitorteam_formation"`
}