Textualizer is a jQuery plug-in that allows you to transition through blurbs of text.  When transitioning to a new blurb, any character that is common to the next blurb is kept on the screen, and moved to its new position.

See it in action [here](http://krisk.github.io/textualizer/#demo)
